'''#####-----Build File-----#####'''
buildfile = '192.168.1.168/kodi/builds/build-addons/omega.xml'

'''#####-----Videos File-----#####'''
videos_url = 'https://raw.githubusercontent.com/Buildtexts69/omegabuilds/main/videos.txt'

'''#####-----Notification File-----#####'''
notify_url  = 'https://raw.githubusercontent.com/Buildtexts69/omegabuilds/main/notify.txt'

'''#####-----Changelog Directory-----#####'''
changelog_dir  = 'https://raw.githubusercontent.com/Buildtexts69/omegabuilds/main/'

'''#####-----Excludes-----#####'''
excludes  = ['plugin.video.whatever']
